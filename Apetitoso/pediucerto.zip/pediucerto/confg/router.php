<?php

if(($route1[0] != 'verifica') 
    && ($route1[0] != 'codigo') 
    && ($route1[0] != 'endereco') 
    && ($route1[0] != 'fPagamento') 
    && ($route1[0] != 'perfil') 
    && ($route1[0] != 'meus_pedidos') 
    && ($route1[0] != 'login_celular')
    && ($route1[0] != 'codigo-verifica')
    && ($route1[0] != 'criar-conta')
    && ($route1[0] != '')){
    $route = array(
        'page' => $route1[0],
        'id' => $route1[1],
        'token' => $route1[2],
    );
    
    $empresa = buscaDadosEmpresa($conexao,$route['id']);

 }
 else if($route1[0] == ''){
    $route = array(
        'page' => $route1[0]
    );
 }
 else if($route1[0] == 'verifica'){
     $route = array(
        'page' => $route1[0],
        'subPage'  => $route1[1],
        'perfil' => $route1[2],
     );
 }

 else if($route1[0] == 'codigo'){
    $route = array(
       'page' => $route1[0],
       'numero'  => substr($route1[1],0 , strpos($route1[1], '=')),
       
    );
}

else if($route1[0] == 'codigo-verifica'){
    $route = array(
       'page' => $route1[0],
       'numero'  => $route1[1],
       
    );
}

else if($route1[0] == 'endereco'){

    if(in_array('cadastrar', $route1)){
        $route = array(
            'page' => $route1[0],
            'subPage'  => $route1[1],
            'perfil' => $route1[3],
        );
    }
    else if(in_array('local_entrega', $route1)){
        $route = array(
            'page' => $route1[0],
            'subPage'  => $route1[1],
            'perfil' => $route1[3],
        );
    }
    else{
        $route = array(
            'page' => $route1[0],
            'subPage'  => $route1[1],
            'perfil' => $route1[2],
        );
    }
    
}
else if($route1[0] == 'fPagamento'){
    $route = array(
        'page' => $route1[0],
    );
}
else if($route1[0] == 'perfil'){
    $route = array(
        'page' => $route1[0],
        'perfil'  => $route1[1],
       
    );
}
else if($route1[0] == 'meus_pedidos'){
    $route = array(
        'page' => $route1[0],
        'subPage'  => $route1[1],
        'perfil' => $route1[2],
       
    );
}
else if($route1[0] == 'login_celular'){
    $route = array(
        'page' => $route1[0],
              
    );
}

else if($route1[0] == 'criar-conta'){
    $route = array(
        'page' => $route1[0],
              
    );
}


else{
    $route = array(
        'page' => 'ERRO 404',
        
     );
}

 //var_dump($route);