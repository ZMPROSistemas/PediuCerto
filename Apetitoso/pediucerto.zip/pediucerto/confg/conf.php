<?php

//$urlBase = 'https://zmsys.com.br/';
$urlBaseImg = 'https://zmsys.com.br/';
//$urlAssets = 'https://zmsys.com.br/pediucerto/';
$urlBase = 'http://localhost/zmpro/';
$urlAssets = 'http://localhost/pediucerto/';


