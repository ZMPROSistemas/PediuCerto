<?php  
    include_once 'resources/views/sacola.html';

    include 'resources/footer.php';
?>
<script>
<?php 
    include_once 'controller/sacola/sacola.js';
    include_once 'controller/app/funcoesBasicas.js';
?>

</script>

</body>
</html>