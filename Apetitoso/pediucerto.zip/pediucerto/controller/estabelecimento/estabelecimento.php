<?php  
    include_once 'resources/views/Inicio.html';

    include 'resources/footer.php';
?>
<script>
<?php 
    include_once 'controller/estabelecimento/estabelecimento.js';
    include_once 'controller/app/funcoesBasicas.js';
?>

</script>

</body>
</html>