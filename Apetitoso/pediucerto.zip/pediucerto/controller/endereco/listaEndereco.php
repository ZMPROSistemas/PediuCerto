<?php  
    include_once 'resources/views/Endereco.html';

    include 'resources/footer.php';
?>
<script>
<?php 
    include_once 'controller/endereco/listaEndereco.js';
    include_once 'controller/app/funcoesBasicas.js';
?>

</script>

</body>
</html>