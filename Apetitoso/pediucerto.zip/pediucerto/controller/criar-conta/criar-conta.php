<?php  

    include_once 'resources/views/Criar_conta.html';

    include_once 'resources/footer.php';
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/danialfarid-angular-file-upload/12.0.4/ng-file-upload.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ng-img-crop/0.3.2/ng-img-crop.js"></script>
<script>
<?php 
    include_once 'controller/criar-conta/criar-conta.js';
    include_once 'controller/app/funcoesBasicas.js';
?>

</script>

</body>
</html>
