$(function() {
    $('#easypiechart-teal').easyPieChart({
        scaleColor: false,
        trackColor: false,
        barColor: '#1ebfae'
    });
});

$(function() {
    $('#easypiechart-orange').easyPieChart({
        scaleColor: false,
        trackColor: false,
        barColor: '#ffb53e'
    });
});

$(function() {
    $('#easypiechart-red').easyPieChart({
        scaleColor: false,
        trackColor: false,
        barColor: '#f9243f'
    });
});

$(function() {
   $('#easypiechart-blue').easyPieChart({
       scaleColor: false,
       trackColor: false,
       barColor: '#30a5ff'
   });
});

$('#calendar').datepicker({
	});
