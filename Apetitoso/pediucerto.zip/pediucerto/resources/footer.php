	
		</div>

	<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.0/angular.min.js"></script>
	<script src="https://code.angularjs.org/1.8.0/angular-animate.min.js"></script>
	<script src="https://code.angularjs.org/1.8.0/angular-messages.min.js"></script>
	<!--script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></!--script-->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	
	
	
    
	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.0/angular-aria.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/angular_material/1.1.24/angular-material.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/angular.js/1.2.20/angular-route.min.js"></script>
	<script src="<?=$urlAssets?>assets/js/angular-locale_pt-br.js"></script>
	<script src="<?=$urlAssets?>assets/js/mask/angular-money-mask.js"></script>

	<script src="https://cdn.jsdelivr.net/gh/cferdinandi/smooth-scroll@15/dist/smooth-scroll.polyfills.min.js"></script>
	<script type="text/javascript" src="<?=$urlAssets?>assets/js/swx-session-storage.min.js"></script>
	<script type="text/javascript" src="<?=$urlAssets?>assets/js/swx-local-storage.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	
	<script src="https://apis.google.com/js/platform.js" async defer></script>
	<script async defer crossorigin="anonymous" src="https://connect.facebook.net/pt_BR/sdk.js#xfbml=1&version=v8.0&appId=2669355246658695&autoLogAppEvents=1" nonce="KXaGaZIe"></script>
	
	

    <!--script src="assets/js/jquery-3.4.1.min.js"></!--script>
    <script src="assets/js/angular.min.js"></script>
    <script src="assets/js/angular-animate.min.js"></script>
    <script src="assets/js/angular-messages.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/mCustomScrollbar.concat.min.js"></script>
	<script src="assets/js/angular-match-media.js"></script>
	<script src="assets/js/angular-material.min.js"></script>
	<script src="assets/js/angular-aria.min.js"></script>
	<script src="assets/js/material-components-web.min.js"></script>
	<script src="assets/js/jquery.mask.min.js"></script>
	<script src="assets/js/dirPagination.js"></script>	
   	<script src="assets/js/angular-locale_pt-br.js"></script>
	<script-- src="http://rawgit.com/daniel-nagy/md-data-table/master/dist/md-data-table.js"></script-->