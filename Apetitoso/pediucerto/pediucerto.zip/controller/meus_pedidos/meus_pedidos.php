<?php

    include_once 'resources/views/meus_pedidos.html';

    include 'resources/footer.php';
    ?>
    <script>
    <?php 
    include_once 'controller/meus_pedidos/meus_pedidos.js';
    include_once 'controller/app/funcoesBasicas.js';
    ?>

</script>

</body>
</html>